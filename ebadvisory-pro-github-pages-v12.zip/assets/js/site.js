/* E&B Advisory : menu, calendrier 3D, pile 3D, compteur, simulateur, formulaire. Aucun traceur. */
(function () {
  'use strict';
  var d = document, w = window;
  var reduce = w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fr = new Intl.NumberFormat('fr-FR');
  function $(s, c) { return (c || d).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  /* Menu mobile */
  var burger = $('.burger');
  if (burger) {
    burger.addEventListener('click', function () {
      var open = d.documentElement.classList.toggle('menu-open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    $$('.sheet a').forEach(function (a) {
      a.addEventListener('click', function () { d.documentElement.classList.remove('menu-open'); burger.setAttribute('aria-expanded', 'false'); });
    });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') { d.documentElement.classList.remove('menu-open'); } });
  }

  /* Barre CTA mobile : apparait apres le premier ecran */
  var mbar = $('.mbar');
  if (mbar) {
    var onScroll = function () { mbar.classList.toggle('show', w.scrollY > w.innerHeight * 0.7); };
    w.addEventListener('scroll', onScroll, { passive: true }); onScroll();
  }

  /* Calendrier 3D du hero : les sessions se remplissent */
  var slots = $$('.slot');
  if (slots.length) {
    var order = [0, 5, 2, 7, 10, 4, 9, 1, 11, 6, 3, 8];
    var filled = 0;
    function setFill(n) {
      slots.forEach(function (s, i) {
        var idx = order.indexOf(i);
        var full = idx > -1 && idx < n;
        s.classList.toggle('full', full);
        var st = $('i', s); if (st) st.textContent = full ? 'Session complète' : 'Session à remplir';
      });
    }
    if (reduce) { setFill(8); }
    else {
      var t0 = null;
      var tick = function (t) {
        if (!t0) t0 = t;
        var n = Math.min(order.length - 3, Math.floor((t - t0) / 420));
        if (n !== filled) { filled = n; setFill(n); }
        if (filled < order.length - 3) requestAnimationFrame(tick);
      };
      setTimeout(function () { requestAnimationFrame(tick); }, 500);
    }
    var cal = $('.cal');
    if (cal && !reduce) {
      w.addEventListener('scroll', function () {
        var p = clamp(w.scrollY / 700, 0, 1);
        cal.style.setProperty('--p', p.toFixed(3));
      }, { passive: true });
    }
  }

  /* Pile 3D de la methode (epinglee au defilement sur grand ecran) */
  var stack = $('.stack');
  if (stack) {
    var cards = $$('.sc', stack), prog = $('.prog', stack);
    var pinned = false;
    var setup = function () {
      var want = !reduce && w.innerWidth > 760 && w.innerHeight > 560;
      if (want === pinned) return;
      pinned = want;
      stack.classList.toggle('pinned', pinned);
      if (!pinned) { cards.forEach(function (c) { c.style.transform = ''; c.style.visibility = ''; c.style.zIndex = ''; c.style.removeProperty('--co'); c.removeAttribute('aria-hidden'); }); }
      else update();
    };
    var update = function () {
      if (!pinned) return;
      var r = stack.getBoundingClientRect();
      var total = r.height - w.innerHeight;
      var raw = clamp(-r.top / total, 0, 1) * (cards.length - 1);
      var fl = Math.min(Math.floor(raw), cards.length - 2), fr2 = raw - fl;
      var tt = clamp((fr2 - 0.5) / 0.5, 0, 1); tt = tt * tt * (3 - 2 * tt);
      var p = raw >= cards.length - 1 ? raw : fl + tt;
      cards.forEach(function (c, i) {
        var dd = i - p, y, z, s, co, vis = 'visible';
        if (dd < 0) { y = dd * 70; z = 0; s = 1 + dd * 0.03; co = clamp(1 + dd * 1.6, 0, 1); if (dd < -1) vis = 'hidden'; }
        else { y = dd * 30; z = -dd * 110; s = 1 - dd * 0.035; co = clamp(1 - dd * 1.7, 0, 1); if (dd > 3.2) vis = 'hidden'; }
        c.style.transform = 'translate(-50%,-50%) translate3d(0,' + y + 'px,' + z + 'px) scale(' + s + ')';
        c.style.setProperty('--co', co);
        c.style.visibility = vis;
        c.style.zIndex = String(100 - Math.round(Math.abs(dd) * 10));
        c.setAttribute('aria-hidden', Math.abs(dd) > 0.6 ? 'true' : 'false');
      });
      if (prog) prog.textContent = (Math.round(p) + 1) + ' / ' + cards.length;
    };
    w.addEventListener('scroll', update, { passive: true });
    w.addEventListener('resize', function () { setup(); update(); });
    setup();
  }

  /* Compteur : une seule fois a l'arrivee dans l'ecran */
  $$('[data-count]').forEach(function (el) {
    var target = parseInt(el.getAttribute('data-count'), 10);
    if (reduce || !('IntersectionObserver' in w)) return;
    el.textContent = '0';
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        io.disconnect();
        var t0 = null;
        var step = function (t) {
          if (!t0) t0 = t;
          var k = clamp((t - t0) / 1800, 0, 1);
          var ease = 1 - Math.pow(1 - k, 3);
          el.textContent = fr.format(Math.round(target * ease));
          if (k < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      });
    }, { threshold: 0.5 });
    io.observe(el);
  });

  /* Simulateur */
  var sim = $('#sim');
  if (sim) {
    var ca = $('#sim-ca'), nb = $('#sim-nb'), av = $('#sim-av');
    var oNb = $('#o-nb'), oAdd = $('#o-add'), oTot = $('#o-tot');
    var eur = function (n) { return fr.format(Math.round(n)) + ' €'; };
    var calc = function () {
      var c = Math.max(0, parseFloat(ca.value) || 0);
      var a = Math.max(0, parseFloat(av.value) || 0);
      var n = parseInt(nb.value, 10) || 0;
      nb.style.setProperty('--v', ((n - 1) / 9 * 100) + '%');
      oNb.textContent = n;
      var add = n * a * 12;
      oAdd.textContent = eur(add);
      oTot.textContent = eur(c + add);
    };
    [ca, nb, av].forEach(function (el) { el.addEventListener('input', calc); });
    calc();
  }

  /* Formulaire apporteurs : validation puis ouverture de la messagerie */
  var form = $('#form-apporteur');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var ok = true;
      $$('[data-req]', form).forEach(function (f) {
        var input = $('input,textarea', f), v = input.value.trim();
        var bad = !v || (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v));
        f.classList.toggle('bad', bad);
        if (bad) ok = false;
      });
      if (!ok) { var first = $('.bad input,.bad textarea', form); if (first) first.focus(); return; }
      var g = function (n) { return form.elements[n].value.trim(); };
      var body = 'Nom : ' + g('nom') + '\nEmail : ' + g('email') + '\nActivité : ' + g('activite') + '\n\n' + g('message');
      var href = 'mailto:christopher@ebadvisory.pro?subject=' + encodeURIComponent('Apporteur d’affaires : ' + g('nom')) + '&body=' + encodeURIComponent(body);
      var ko = $('.form-ok'); if (ko) { ko.classList.add('show'); ko.focus(); }
      w.location.href = href;
    });
  }
})();
