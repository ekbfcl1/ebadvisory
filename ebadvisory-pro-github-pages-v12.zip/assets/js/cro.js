/* E&B Advisory : couche conversion. Aucun traceur, aucun cookie. */
(function () {
  'use strict';
  var d = document, w = window, de = d.documentElement;
  var NUM = '33768677831';
  var WA_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';
  function $(s, c) { return (c || d).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); }
  function store(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) {} return null; }

  /* Lien WhatsApp : le message arrive prérempli avec la page d'où vient la personne */
  var page = (d.title || '').split(' | ')[0].split(' : ')[0];
  var msg = 'Bonjour Christopher, je dirige un organisme de formation et je souhaite un diagnostic de remplissage. (Page : ' + page + ')';
  var wa = 'https://wa.me/' + NUM + '?text=' + encodeURIComponent(msg);
  $$('[data-wa]').forEach(function (a) { a.href = wa; a.target = '_blank'; a.rel = 'noopener'; });

  /* Chargement : retire le rideau dès que la page est prête */
  var pre = $('#pre');
  if (pre) {
    var kill = function () { setTimeout(function () { if (pre.parentNode) pre.parentNode.removeChild(pre); de.classList.remove('pre-on'); }, 1500); };
    if (d.readyState === 'complete') kill(); else w.addEventListener('load', kill);
  }

  /* Barre d'annonce */
  var abar = $('.abar');
  if (abar) {
    var close = $('.abar-x', abar);
    if (close) close.addEventListener('click', function () { de.classList.add('abar-off'); store('eb_abar', '1'); de.style.removeProperty('--ab'); });
    var onS = function () { de.style.setProperty('--ab', Math.max(0, 36 - w.scrollY) + 'px'); };
    w.addEventListener('scroll', function () { if (!de.classList.contains('abar-off')) onS(); }, { passive: true }); onS();
  }

  var legal = /^\/(mentions-legales|confidentialite|cookies)\//.test(location.pathname) || d.title.indexOf('Page introuvable') > -1;
  if (legal) return;

  /* Bouton WhatsApp flottant (bureau) : après le premier écran, masqué sur les blocs de conversion */
  var fl = d.createElement('a');
  fl.className = 'wa-float'; fl.href = wa; fl.target = '_blank'; fl.rel = 'noopener';
  fl.innerHTML = WA_SVG + '<span>Écrire à Christopher</span>';
  d.body.appendChild(fl);
  var closing = $('.closing');
  var onF = function () { fl.classList.toggle('show', w.scrollY > w.innerHeight * 0.6); };
  w.addEventListener('scroll', onF, { passive: true }); onF();
  if (closing && 'IntersectionObserver' in w) {
    new IntersectionObserver(function (e) { fl.classList.toggle('hide', e[0].isIntersecting); }).observe(closing);
  }

  /* Panneau de sortie : bureau, une seule fois par visite, après 15 s sur la page */
  if (w.matchMedia && w.matchMedia('(min-width:981px) and (hover:hover)').matches && !store('eb_exit')) {
    var armed = false, p = null;
    setTimeout(function () { armed = true; }, 15000);
    var open = function () {
      if (p || !armed || store('eb_exit')) return;
      store('eb_exit', '1');
      p = d.createElement('div');
      p.className = 'exit-p'; p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'Diagnostic gratuit');
      p.innerHTML = '<button class="exit-x" type="button" aria-label="Fermer">×</button>' +
        '<h3>Combien de sessions votre zone peut-elle remplir ?</h3>' +
        '<p>Trente minutes avec moi, gratuites et sans engagement. Je vous dis honnêtement si le dispositif est adapté à votre organisme.</p>' +
        '<div class="row"><a class="btn btn-navy" href="https://calendly.com/ebadvisory" target="_blank" rel="noopener">Réserver mon diagnostic</a>' +
        '<a class="btn btn-wa" href="' + wa + '" target="_blank" rel="noopener">' + WA_SVG + 'WhatsApp</a></div>';
      d.body.appendChild(p);
      requestAnimationFrame(function () { requestAnimationFrame(function () { p.classList.add('show'); }); });
      $('.exit-x', p).addEventListener('click', function () { p.classList.remove('show'); });
      d.addEventListener('keydown', function (e) { if (e.key === 'Escape') p.classList.remove('show'); });
    };
    d.addEventListener('mouseout', function (e) { if (!e.relatedTarget && e.clientY <= 0) open(); });
  }
})();
